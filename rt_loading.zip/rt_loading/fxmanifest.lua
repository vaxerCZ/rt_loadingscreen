fx_version 'cerulean'
game 'gta5'

description 'Liquid Glass Loading Screen'
version '1.0.0'

loadscreen 'html/index.html'
loadscreen_cursor 'yes'

files {
    'html/index.html',
    'html/style.css',
    'html/script.js',
    'html/config.js',
    -- Note: Ensure these assets exist in your local folder or update the config to use URLs
    'html/assets/video/background.mp4',
    'html/assets/music/*.mp3',
    'html/assets/images/*.jpg',
    'html/assets/images/*.png'
}
