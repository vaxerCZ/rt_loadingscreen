let currentTrackIndex = 0;
let galleryIndex = 0;
const audio = new Audio();
let isPlaying = false;

function init() {
    // 1. Initialize Theme
    document.body.className = `theme-${Config.themeColor || 'blue'}`;

    // 2. Initialize UI States based on Config
    if (!Config.showGallery) document.getElementById('gallery-card').classList.add('hidden');
    if (!Config.showServerInfo) document.getElementById('server-info').classList.add('hidden');
    if (!Config.showDescription) document.getElementById('server-desc').classList.add('hidden');
    
    // 3. Set Server Text
    document.getElementById('server-name').innerText = Config.serverName;
    document.getElementById('server-desc').innerText = Config.serverDescription;
    document.getElementById('overlay-server-name').innerText = Config.serverName;

    // 4. Setup Socials
    const socialCont = document.getElementById('social-links');
    if (Config.showSocials) {
        Config.socials.forEach(s => {
            const btn = document.createElement('a');
            btn.href = s.url;
            btn.target = "_blank";
            btn.innerHTML = `<i class="${s.icon}"></i>`;
            socialCont.appendChild(btn);
        });
    }

    // 5. Initialize Audio Settings
    audio.volume = 0.5;
    loadTrack(0);

    // 6. Initialize Gallery
    if (Config.showGallery) {
        updateGallery();
    }

    // 7. Setup Interaction Listeners
    setupListeners();
    setupLiquidGlass();
}

function loadTrack(index) {
    const track = Config.playlist[index];
    if (!track) return;
    
    document.getElementById('track-name').innerText = track.title;
    document.getElementById('track-artist').innerText = track.artist;
    document.getElementById('track-cover').src = track.cover;
    audio.src = track.file;
    if (isPlaying) audio.play();
}

function togglePlay() {
    if (audio.paused) {
        audio.play().then(() => {
            isPlaying = true;
            document.getElementById('play-pause').className = "fa-solid fa-circle-pause main-btn";
        }).catch(err => console.log("Audio play blocked: ", err));
    } else {
        audio.pause();
        isPlaying = false;
        document.getElementById('play-pause').className = "fa-solid fa-circle-play main-btn";
    }
}

function setupListeners() {
    // Start Button Overlay (fixes autoplay policy)
    document.getElementById('start-btn').addEventListener('click', () => {
        document.getElementById('start-overlay').style.opacity = '0';
        setTimeout(() => {
            document.getElementById('start-overlay').style.visibility = 'hidden';
            togglePlay(); // Easier start - starts music and UI
        }, 500);
    });

    // Audio Controls
    document.getElementById('play-pause').addEventListener('click', togglePlay);
    
    document.getElementById('next-song').addEventListener('click', () => {
        currentTrackIndex = (currentTrackIndex + 1) % Config.playlist.length;
        loadTrack(currentTrackIndex);
    });

    document.getElementById('prev-song').addEventListener('click', () => {
        currentTrackIndex = (currentTrackIndex - 1 + Config.playlist.length) % Config.playlist.length;
        loadTrack(currentTrackIndex);
    });

    // Volume
    const volSlider = document.getElementById('volume-slider');
    volSlider.addEventListener('input', (e) => {
        const val = e.target.value;
        audio.volume = val;
        const icon = document.getElementById('vol-icon');
        if (val == 0) icon.className = "fa-solid fa-volume-xmark";
        else if (val < 0.5) icon.className = "fa-solid fa-volume-low";
        else icon.className = "fa-solid fa-volume-high";
    });

    // Gallery Controls
    document.getElementById('next-btn')?.addEventListener('click', () => {
        galleryIndex = (galleryIndex + 1) % Config.gallery.length;
        updateGallery();
    });

    document.getElementById('prev-btn')?.addEventListener('click', () => {
        galleryIndex = (galleryIndex - 1 + Config.gallery.length) % Config.gallery.length;
        updateGallery();
    });

    // Auto-advance gallery
    setInterval(() => {
        if (Config.showGallery) {
            galleryIndex = (galleryIndex + 1) % Config.gallery.length;
            updateGallery();
        }
    }, 6000);
}

function updateGallery() {
    if (Config.gallery.length === 0) return;
    const imgElement = document.getElementById('gallery-img');
    imgElement.style.opacity = '0';
    setTimeout(() => {
        imgElement.src = Config.gallery[galleryIndex];
        imgElement.style.opacity = '1';
    }, 200);
}

// FiveM Bridge
window.addEventListener('message', (event) => {
    if (event.data.type === 'loadProgress') {
        const progress = event.data.value; // Expected 1 to 100
        const progressBar = document.getElementById('load-progress');
        const progressText = document.querySelector('.progress-time');
        
        if (progressBar) progressBar.style.width = progress + '%';
        if (progressText) progressText.innerText = Math.round(progress) + '%';
    }
});

// 3D Liquid Glass tilt effect
function setupLiquidGlass() {
    const cards = document.querySelectorAll('.glass-card');
    cards.forEach(card => {
        card.addEventListener('mousemove', e => {
            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;

            const centerX = rect.width / 2;
            const centerY = rect.height / 2;

            const rotateX = ((y - centerY) / centerY) * -10;
            const rotateY = ((x - centerX) / centerX) * 10;

            card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale3d(1.02, 1.02, 1.02)`;
        });

        card.addEventListener('mouseleave', () => {
            card.style.transform = `perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)`;
        });
    });
}

// Initial Call
init();
