window.Config = {

    // ADD YOUR VIDEO IN assets/video/background.mp4 - NAME IT background.mp4!
    // ADD YOUR OWN MUSIC IN assets/music/song(number).mp3 - NAME IT song(number).mp3!


    // UI Theme options: 'red', 'blue', 'white', 'green', 'purple', 'yellow', 'orange', 'cyan', 'pink', 'gold'
    themeColor: 'red',

    // Toggle UI Modules
    showGallery: false,
    showServerInfo: false,
    showSocials: true,
    showDescription: true,

    // Server Branding
    serverName: "RTZUS DEVELOPMENT",
    serverDescription: "Best scripts on the market. Loading, that you see is right now free on GitHub! Thanks, for using it!",

    // Music Playlist
    // Use local paths like 'assets/music/song1.mp3' or direct URLs
    playlist: [
        {
            title: "Let Me Love You",
            artist: "DJ Snake",
            cover: "https://upload.wikimedia.org/wikipedia/commons/thumb/5/5f/Apple_Music_icon.svg/960px-Apple_Music_icon.svg.png", 
            file: "assets/music/song3.mp3" 
        },
        {
            title: "Danza Kuduro",
            artist: "Don Omar",
            cover: "https://upload.wikimedia.org/wikipedia/commons/thumb/5/5f/Apple_Music_icon.svg/960px-Apple_Music_icon.svg.png",
            file: "assets/music/song2.mp3"
        }
    ],

    // Gallery Images
    gallery: [
        "https://www.pcgamesn.com/wp-content/sites/pcgamesn/2021/04/gta-5-fivem-player-count.jpg",
        "https://shadow.tech/app/uploads/2025/07/GTA-V-Game-insight-FiveM.jpg",
        "https://img.gta5-mods.com/q95/images/free-gtav-fivem-graphics-pack-by-sipi/fce337-Screenshot_1574.jpg"
    ],

    // Social Links
    socials: [
        { name: "Discord", icon: "fa-brands fa-discord", url: "https://discord.gg/yourlink" },
        { name: "Store", icon: "fa-solid fa-cart-shopping", url: "https://your-store.com" },
        { name: "Youtube", icon: "fa-brands fa-youtube", url: "https://youtube.com/yourlink" }
    ]
};
